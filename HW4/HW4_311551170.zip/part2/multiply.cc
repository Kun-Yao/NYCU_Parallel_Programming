#include <mpi.h>
#include <fstream>
#include <iostream>

using namespace std;
// Read size of matrix_a and matrix_b (n, m, l) and whole data of matrixes from in
//
// in:        input stream of the matrix file
// n_ptr:     pointer to n
// m_ptr:     pointer to m
// l_ptr:     pointer to l
// a_mat_ptr: pointer to matrix a (a should be a continuous memory space for placing n * m elements of int)
// b_mat_ptr: pointer to matrix b (b should be a continuous memory space for placing m * l elements of int)
void construct_matrices(std::ifstream &in, int *n_ptr, int *m_ptr, int *l_ptr,
                        int **a_mat_ptr, int **b_mat_ptr)
{
    if (!in.is_open()) {
        throw std::runtime_error("File not opened");
    }

    int world_rank, world_size;
    int rows_message, begin_message;
    int n, m, l;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

    if (world_rank == 0){
        in >> *n_ptr >> *m_ptr >> *l_ptr;
        
        n = *n_ptr;
        m = *m_ptr;
        l = *l_ptr;

        *a_mat_ptr = (int *)calloc(n * m, sizeof(int));

        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                in >> (*a_mat_ptr)[i * m + j];
            }
        }
        
        *b_mat_ptr = (int *)calloc(m * l, sizeof(int));

        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < l; ++j) {
                in >> (*b_mat_ptr)[i * l + j];
            }
        }
    }
}

// Just matrix multiplication (your should output the result in this function)
// 
// n:     row number of matrix a
// m:     col number of matrix a / row number of matrix b
// l:     col number of matrix b
// a_mat: a continuous memory placing n * m elements of int
// b_mat: a continuous memory placing m * l elements of int
void matrix_multiply(const int n, const int m, const int l,
                     const int *a_mat, const int *b_mat)
{
    int world_rank, world_size;
    int rows_r, rows_q, rows, start=0;
    int *local_a, *local_b, *local_c, *c_mat;
    int N, M, L;

    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    
    // MPI_Status status;
    // MPI_Request request;
    if (world_rank == 0){
        int* start_a = (int*)calloc(world_size, sizeof(int));
        int* rows_a = (int*)calloc(world_size, sizeof(int));

        rows_q = n / world_size;
        rows_r = n % world_size;
        rows = (0 < rows_r) ? rows_q + 1 : rows_q;
        rows_a[0] = rows;

        c_mat = (int *)calloc(n * l, sizeof(int));
        for (int k = 0; k < l; k++){
            for (int i = 0; i < rows; i++){
                for (int j = 0; j < m; j++){
                    c_mat[i * l + k] += a_mat[i * m + j] * b_mat[j * l + k];
                }
            }
        }

        MPI_Request matinfo_to_worker, mat_to_worker[2], mat_from_worker[world_size - 1];
        for (int i = 1; i < world_size; i++){            
            start += rows;
            start_a[i] = start;
            rows = (i < rows_r) ? rows_q + 1 : rows_q;
            rows_a[i] = rows;
            int mat_info[] = {n, m, l, rows};
            // MPI_Send(&mat_info[0], 4, MPI_INT, i, 0, MPI_COMM_WORLD)
            // MPI_Send(&a_mat[start * m], rows * m, MPI_INT, i, 0, MPI_COMM_WORLD);
            // MPI_Send(&b_mat[0], m * l, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Isend(&mat_info[0], 4, MPI_INT, i, 0, MPI_COMM_WORLD, &matinfo_to_worker); 
            MPI_Wait(&matinfo_to_worker, MPI_STATUS_IGNORE);
            MPI_Isend(&a_mat[start * m], rows * m, MPI_INT, i, 0, MPI_COMM_WORLD, &mat_to_worker[0]);
            MPI_Isend(&b_mat[0], m * l, MPI_INT, i, 0, MPI_COMM_WORLD, &mat_to_worker[1]);
            MPI_Waitall(2, mat_to_worker, MPI_STATUS_IGNORE);
        }

        //receive compute results from other workers
        for (int i = 1; i < world_size; i++){
            // MPI_Recv(&c_mat[start_a[i] * l], n * l, MPI_INT, i, 0, MPI_COMM_WORLD, &status);
            MPI_Irecv(&c_mat[start_a[i] * l], n * l, MPI_INT, i, 0, MPI_COMM_WORLD, &mat_from_worker[i-1]);
        }
        MPI_Waitall(world_size - 1, mat_from_worker, MPI_STATUS_IGNORE);
        
        //print c_mat
        for (int i = 0; i < n; i++){
            for (int j = 0; j < l; j++){
                printf("%d ", c_mat[i * l + j]);
            }
            printf("\n");
        }
        free(c_mat);
        free(start_a);
        free(rows_a);
    }
    else{
        // MPI_Recv(&N, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        // MPI_Recv(&M, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        // MPI_Recv(&L, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        int mat_info[4];
        // MPI_Status status;
        MPI_Request matinfo_from_master, matinfo_to_master, mat_to_master, mat_from_master[2];
        // MPI_Recv(&mat_info[0], 4, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        MPI_Irecv(&mat_info[0], 4, MPI_INT, 0, 0, MPI_COMM_WORLD, &matinfo_from_master);
        MPI_Wait(&matinfo_from_master, MPI_STATUS_IGNORE);
        N = mat_info[0], M = mat_info[1], L = mat_info[2], rows = mat_info[3];

        local_a = (int *)calloc(N * M, sizeof(int));
        local_b = (int *)calloc(M * L, sizeof(int));
        local_c = (int *)calloc(N * L, sizeof(int));

        // MPI_Recv(&local_a[0], N * M, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        // MPI_Recv(&local_b[0], M * L, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        MPI_Irecv(&local_a[0], N * M, MPI_INT, 0, 0, MPI_COMM_WORLD, &mat_from_master[0]);
        MPI_Irecv(&local_b[0], M * L, MPI_INT, 0, 0, MPI_COMM_WORLD, &mat_from_master[1]);
        MPI_Waitall(2, mat_from_master, MPI_STATUS_IGNORE);

        for (int k = 0; k < L; k++){
            for (int i = 0; i < rows; i++){
                for (int j = 0; j < M; j++){
                    local_c[i * L + k] += local_a[i * M + j] * local_b[j * L + k];
                }
            }
        }

        // MPI_Send(&rows, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
        // MPI_Send(&start, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
        // MPI_Send(&local_c[0], rows * L, MPI_INT, 0, 0, MPI_COMM_WORLD);
        MPI_Isend(&local_c[0], rows * L, MPI_INT, 0, 0, MPI_COMM_WORLD, &mat_to_master);
        MPI_Wait(&mat_to_master, MPI_STATUS_IGNORE);
    free(local_a);
    free(local_b);
    free(local_c);
    }
    
    
}

void destruct_matrices(int *a_mat, int *b_mat)
{
    int world_rank, world_size;
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    if (world_rank == 0){
        free(a_mat);
        free(b_mat);
    }
}